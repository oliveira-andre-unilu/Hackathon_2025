# Summary

- [Introduction](../README.md)

# Deep dive

- [Storage notes](storage-notes.md)
- [Unverified devices](warning-on-unverified-devices.md)
