## Dump of a libolm indexeddb cryptostore where the identity is not trusted.

A dump of an account where the identity was not verified.
Used as a test case for migration of the identity local trust.
