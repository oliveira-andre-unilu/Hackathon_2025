## Dump of a libolm indexeddb cryptostore where the msk is not cached

A dump simulating an account where the identity was verified, but the msk was not in cache.
Used to test that the owner identity local trust is migrated correctly.
