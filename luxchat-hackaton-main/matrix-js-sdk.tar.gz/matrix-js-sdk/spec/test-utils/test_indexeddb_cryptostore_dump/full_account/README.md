## Dump of a libolm indexeddb cryptostore to test migration of a full account

A dump of an account containing a complete set of data to migrate.
The data set is substantial enough to allow for testing of chunking mechanisms and progress reporting during the migration process.
