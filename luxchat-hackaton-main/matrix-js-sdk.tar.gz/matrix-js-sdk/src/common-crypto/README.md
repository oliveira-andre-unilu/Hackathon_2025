This directory contains functionality which is common to both the legacy (libolm-based) crypto implementation,
and the new rust-based implementation.

It is an internal module, and is _not_ directly exposed to applications.
