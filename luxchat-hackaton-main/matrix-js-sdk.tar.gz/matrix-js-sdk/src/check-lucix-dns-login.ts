export class CheckLucixDnsLogin {

    public static async checkDns(domain: string): Promise<any> {

        const homeserverDnsToken = process.env.HOMESERVER_DNS_TOKEN ?? '';
        const homeserverDnsUrl = process.env.HOMESERVER_DNS_URL ?? '';
        const userAgent = process.env.XCUSTOM_USER_AGENT ?? '';

        try {
            const response = await fetch(homeserverDnsUrl, {
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${homeserverDnsToken}`,
                    'Content-Type': 'application/json',
                    'XCustomUserAgent': userAgent
                },
                body: JSON.stringify({
                    domain_alias: domain,
                }),
            });

            if (!response.ok) {
                throw new Error(`Request failed with status ${response.status}`);
            }
            const data = await response.json();
            return data.domain;
        } catch (err) {
            console.error("Erreur:", err);
            throw err;
        }
    }
    public static async getAliasFromHomeserver(homeserverUrl: string): Promise<any> {

        const homeserverDnsToken = process.env.HOMESERVER_DNS_TOKEN ?? '';
        const homeserverDnsUrl = process.env.HOMESERVER_DNS_URL ?? '';
        const userAgent = process.env.XCUSTOM_USER_AGENT ?? '';

        try {
            const response = await fetch(homeserverDnsUrl, {
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${homeserverDnsToken}`,
                    'Content-Type': 'application/json',
                    'XCustomUserAgent': userAgent
                },
                body: JSON.stringify({
                    domain_alias: homeserverUrl,
                }),
            });

            if (!response.ok) {
                throw new Error(`Request failed with status ${response.status}`);
            }
            const data = await response.json();
            return data.domain;
        } catch (err) {
            console.error("Erreur:", err);
            throw err;
        }
    }
}